#import <Flutter/Flutter.h>

@interface SvgaplayerFlutterPlugin : NSObject<FlutterPlugin>
@end
